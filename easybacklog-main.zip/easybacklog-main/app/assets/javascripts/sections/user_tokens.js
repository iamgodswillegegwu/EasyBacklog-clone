//= require ../models/user_token.js
//= require ../collections/user_tokens_collection.js
//= require ../templates/user_tokens/show.jst.ejs
//= require ../views/user_tokens_view.js