// for a few particular features we need to know we are in a test environment i.e. opening new windows
App.environment = 'test';