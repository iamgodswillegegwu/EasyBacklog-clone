//= require conditional/jquery.lightbox-0.5
//= require sections/welcome