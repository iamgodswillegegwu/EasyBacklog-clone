//= require jquery
//= require jquery_ujs
//= require vendor_all/underscore
//= require vendor_all
//= require_tree ./shared
//= require_tree ./locale
//= require views/notice_view.js
//= require templates/layouts/confirm-dialog