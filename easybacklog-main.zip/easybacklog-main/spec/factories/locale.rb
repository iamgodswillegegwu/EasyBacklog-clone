FactoryGirl.define do
  factory :locale do
    name 'British English'
    code 'en-GB'
    position 1
  end
end