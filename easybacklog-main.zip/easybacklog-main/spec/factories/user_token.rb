FactoryGirl.define do
  factory :user_token do
    association :user
  end
end