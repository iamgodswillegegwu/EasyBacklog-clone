metric "User accounts (individual users)" do
  description "Measures how many people have a login"
  model User
end