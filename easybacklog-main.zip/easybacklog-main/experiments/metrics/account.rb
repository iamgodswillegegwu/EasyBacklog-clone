metric "Account set up (company account)" do
  description "Measures how many people set up a new account"
  model Account
end