metric "Backlogs" do
  description "Measures how many backlogs have been created"
  model Backlog
end