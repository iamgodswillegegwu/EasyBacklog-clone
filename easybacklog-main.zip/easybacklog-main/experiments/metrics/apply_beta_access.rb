metric "Apply (for beta access)" do
  description "Measures how many people applied for beta access"
  model BetaSignup
end