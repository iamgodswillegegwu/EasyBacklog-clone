ab_test "Show Beta Intro Video" do
  description "Automatically display the intro video to new users"
  metrics :apply_beta_access
end
