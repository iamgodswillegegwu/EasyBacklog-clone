class ActionMailerBase < ActionMailer::Base
  default :from => "easyBacklog <no-reply@easybacklog.com>"
end
